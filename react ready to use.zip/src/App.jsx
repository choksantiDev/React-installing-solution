import React from 'react';
import "sweetalert2/dist/sweetalert2.min.css";
import "@fortawesome/fontawesome-free/css/all.min.css";
import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";


export default function App() {
  return <div></div>;
}
